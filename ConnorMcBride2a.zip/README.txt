Hi. So all of the data for the graphs is stored in the excel file. All of the config files are included outside the source (for Eclipse) and inside the source folder (for command line running).
How to run:
cd src
javac *.java
java GPac <*.config>

without the < > of course and the * being whichever config file you wish to run. The results file will be named *.config.log. Also the log file for the last eval can be found out worldmap.log
The graphs are found in graphs.pdf